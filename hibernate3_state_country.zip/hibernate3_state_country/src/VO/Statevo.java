package VO;

public class Statevo {
	
	private int stateid;
	private String statename;
	
	private Countryvo countryvo;

	public int getStateid() {
		return stateid;
	}

	public void setStateid(int stateid) {
		this.stateid = stateid;
	}

	public String getStatename() {
		return statename;
	}

	public void setStatename(String statename) {
		this.statename = statename;
	}

	public Countryvo getCountryvo() {
		return countryvo;
	}

	public void setCountryvo(Countryvo countryvo) {
		this.countryvo = countryvo;
	}
	
}
