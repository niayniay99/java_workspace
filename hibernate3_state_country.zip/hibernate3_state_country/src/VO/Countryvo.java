package VO;

public class Countryvo {
	private int id;
	private String countryname;
	private String countrydesc;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCountryname() {
		return countryname;
	}

	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}

	public String getCountrydesc() {
		return countrydesc;
	}

	public void setCountrydesc(String countrydesc) {
		this.countrydesc = countrydesc;
	}

}
